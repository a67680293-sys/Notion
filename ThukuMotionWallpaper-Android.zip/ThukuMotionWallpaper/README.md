# Motion Wallpaper

A native Android live-wallpaper app for turning a local video or HTTPS video URL into a real system live wallpaper.

## What changed

The original project mixed a tiny Android overlay prototype with a separate generated web portal. This rebuild removes that split and uses Android's native `WallpaperService` architecture.

### Core features

- Real Android live wallpaper service, selectable from the system wallpaper picker
- Local video selection with persistable URI permission when the provider supports it
- HTTPS video URL support (including direct MP4 and adaptive HLS/DASH manifests when supplied as playable URLs)
- Smooth in-app video preview
- Built-in animated fallback preview so the app is usable before a video is selected
- Looping playback
- Playback speed from 0.5× to 2.0×
- Optional audio
- Cover / fit scaling
- Recent-source library
- One-tap system wallpaper preview / apply flow
- Clean adaptive-style icon and wallpaper thumbnail
- Visibility-aware playback so the video pauses when the wallpaper is not visible
- Minimal permissions: INTERNET only

## Build

Open the project in Android Studio and let it sync with the Gradle configuration. The project uses Android Gradle Plugin 9.4.1, Gradle 9.6.0, compile/target SDK 36, and Java 17 bytecode. AGP 9+ supplies built-in Kotlin support.

CLI build, on a machine with Gradle 9.6.0 available:

```bash
gradle :app:assembleDebug
```

Because the supplied source archive contained a corrupt Gradle wrapper JAR, this rebuilt archive intentionally does not carry forward that broken binary. Android Studio can sync and build the project directly, or a valid local Gradle installation can be used.

## Usage

1. Open Motion Wallpaper.
2. Tap **Choose video** and select a local video, or use one of the source-management options in the app.
3. Adjust speed, audio, and frame fit.
4. Tap **Set wallpaper**.
5. Android opens the system live-wallpaper preview. Confirm the system's wallpaper action there.

The wallpaper service pauses playback while hidden and releases the player when destroyed.

## Phone-only build route

The repository includes a GitHub Actions build workflow. Upload this project to a GitHub repository, push it to `main` or `master`, and the workflow will run static verification, unit tests, lint, and the debug APK build. The APK is published as a workflow artifact.

## Verification

Run the dependency-free structural checks locally with:

```bash
python3 scripts/verify_static.py
```
