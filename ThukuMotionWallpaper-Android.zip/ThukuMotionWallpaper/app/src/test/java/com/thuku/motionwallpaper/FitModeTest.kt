package com.thuku.motionwallpaper

import org.junit.Assert.assertEquals
import org.junit.Test

class FitModeTest {
    @Test
    fun labels_are_stable() {
        assertEquals("Cover", FitMode.COVER.label())
        assertEquals("Fit", FitMode.CONTAIN.label())
    }
}
