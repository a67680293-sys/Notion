package com.thuku.motionwallpaper.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class AnimatedPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowA = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowB = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val frame = object : Runnable {
        override fun run() {
            t += 0.016f
            invalidate()
            postDelayed(this, 16L)
        }
    }

    init {
        post(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        backgroundPaint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF050608.toInt(), 0xFF11161C.toInt(), 0xFF07090C.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, backgroundPaint)

        val ax = w * (0.24f + 0.07f * cos(t * 0.65f))
        val ay = h * (0.30f + 0.08f * sin(t * 0.55f))
        val bx = w * (0.78f + 0.06f * sin(t * 0.45f))
        val by = h * (0.72f + 0.09f * cos(t * 0.58f))

        glowA.shader = RadialGradient(ax, ay, w * 0.42f, 0x33E9FF6A, 0x00000000, Shader.TileMode.CLAMP)
        glowB.shader = RadialGradient(bx, by, w * 0.35f, 0x226AE5FF, 0x00000000, Shader.TileMode.CLAMP)
        canvas.drawCircle(ax, ay, w * 0.42f, glowA)
        canvas.drawCircle(bx, by, w * 0.35f, glowB)

        accentPaint.color = 0xFFE9FF6A.toInt()
        val cx = w / 2f
        val cy = h / 2f
        val pulse = 1f + 0.035f * sin(t * 2.1f)
        val r = minOf(w, h) * 0.10f * pulse
        canvas.drawCircle(cx, cy, r, accentPaint)
        accentPaint.color = 0xFF121600.toInt()
        canvas.drawPath(android.graphics.Path().apply {
            moveTo(cx - r * 0.24f, cy - r * 0.52f)
            lineTo(cx + r * 0.56f, cy)
            lineTo(cx - r * 0.24f, cy + r * 0.52f)
            close()
        }, accentPaint)
    }
}
