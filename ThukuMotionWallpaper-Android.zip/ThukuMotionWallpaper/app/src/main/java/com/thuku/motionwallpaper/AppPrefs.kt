package com.thuku.motionwallpaper

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri

object AppPrefs {
    private const val NAME = "motion_wallpaper"

    const val KEY_SOURCE_URI = "source_uri"
    const val KEY_SOURCE_NAME = "source_name"
    const val KEY_MUTED = "muted"
    const val KEY_SPEED = "speed"
    const val KEY_FIT_MODE = "fit_mode"
    private const val RECENTS = "recents"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun registerListener(
        context: Context,
        listener: SharedPreferences.OnSharedPreferenceChangeListener
    ) = prefs(context).registerOnSharedPreferenceChangeListener(listener)

    fun unregisterListener(
        context: Context,
        listener: SharedPreferences.OnSharedPreferenceChangeListener
    ) = prefs(context).unregisterOnSharedPreferenceChangeListener(listener)

    fun sourceUri(context: Context): String? = prefs(context).getString(KEY_SOURCE_URI, null)

    fun sourceName(context: Context): String =
        prefs(context).getString(KEY_SOURCE_NAME, "Built-in motion demo")
            ?: "Built-in motion demo"

    fun muted(context: Context): Boolean = prefs(context).getBoolean(KEY_MUTED, true)

    fun speed(context: Context): Float = prefs(context).getFloat(KEY_SPEED, 1f)

    fun fitMode(context: Context): FitMode = when (
        prefs(context).getString(KEY_FIT_MODE, FitMode.COVER.name)
    ) {
        FitMode.CONTAIN.name -> FitMode.CONTAIN
        else -> FitMode.COVER
    }

    fun setSource(context: Context, uri: Uri?, name: String? = null) {
        val editor = prefs(context).edit()
        if (uri == null) {
            editor.remove(KEY_SOURCE_URI).remove(KEY_SOURCE_NAME)
        } else {
            editor.putString(KEY_SOURCE_URI, uri.toString())
                .putString(KEY_SOURCE_NAME, name ?: uri.lastPathSegment ?: "Video wallpaper")
        }
        editor.apply()
    }

    fun setMuted(context: Context, muted: Boolean) =
        prefs(context).edit().putBoolean(KEY_MUTED, muted).apply()

    fun setSpeed(context: Context, speed: Float) =
        prefs(context).edit().putFloat(KEY_SPEED, speed.coerceIn(0.5f, 2f)).apply()

    fun setFitMode(context: Context, mode: FitMode) =
        prefs(context).edit().putString(KEY_FIT_MODE, mode.name).apply()

    fun recentUris(context: Context): List<String> {
        val raw = prefs(context).getString(RECENTS, "") ?: ""
        return raw.split(';')
            .filter(String::isNotBlank)
            .mapNotNull { encoded -> runCatching { Uri.decode(encoded) }.getOrNull() }
            .distinct()
    }

    fun addRecent(context: Context, uri: Uri) {
        val normalized = uri.toString()
        val list = buildList {
            add(normalized)
            addAll(recentUris(context).filterNot { it == normalized })
        }.take(8)
        prefs(context).edit()
            .putString(RECENTS, list.joinToString(";") { Uri.encode(it) })
            .apply()
    }

    fun clearRecent(context: Context) = prefs(context).edit().remove(RECENTS).apply()

    fun reset(context: Context) = prefs(context).edit().clear().apply()
}

enum class FitMode {
    COVER,
    CONTAIN;

    fun label(): String = when (this) {
        COVER -> "Cover"
        CONTAIN -> "Fit"
    }
}
