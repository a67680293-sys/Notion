package com.thuku.motionwallpaper

import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.radiobutton.MaterialRadioButton
import com.thuku.motionwallpaper.wallpaper.VideoWallpaperService
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {
    private lateinit var playerView: PlayerView
    private lateinit var animatedPreview: View
    private lateinit var previewLabel: TextView
    private lateinit var previewMeta: TextView
    private lateinit var previewToggle: MaterialButton
    private lateinit var currentSourceName: TextView
    private lateinit var currentSourceUri: TextView
    private lateinit var statusText: TextView
    private lateinit var libraryList: LinearLayout
    private lateinit var speedSlider: Slider
    private lateinit var speedValue: TextView
    private lateinit var audioSwitch: MaterialSwitch
    private lateinit var fitCover: MaterialRadioButton
    private lateinit var fitContain: MaterialRadioButton

    private var previewPlayer: ExoPlayer? = null
    private var previewUserWantsPlayback = true

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) handlePickedVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.enableEdgeToEdge(window)
        setContentView(R.layout.activity_main)

        bindViews()
        applySystemBarInsets()
        configureNavigation()
        configureActions()
        applyPersistedSettings()
        refreshSourceCard()
        refreshStatus()
        renderLibrary()
        runEntranceAnimation()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshSourceCard()
        configurePreviewPlayer()
    }

    override fun onPause() {
        super.onPause()
        // The preview is a UI convenience, not a background player.
        previewPlayer?.let {
            previewUserWantsPlayback = it.isPlaying
            it.pause()
        }
    }

    override fun onDestroy() {
        previewPlayer?.release()
        previewPlayer = null
        super.onDestroy()
    }

    private fun applySystemBarInsets() {
        val toolbar = findViewById<View>(R.id.toolbar)
        val bottomNavigation = findViewById<View>(R.id.bottomNavigation)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            toolbar.updatePadding(top = bars.top)
            bottomNavigation.updatePadding(bottom = bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(findViewById(R.id.root))
    }

    private fun bindViews() {
        playerView = findViewById(R.id.previewPlayer)
        animatedPreview = findViewById(R.id.animatedPreview)
        previewLabel = findViewById(R.id.previewLabel)
        previewMeta = findViewById(R.id.previewMeta)
        previewToggle = findViewById(R.id.previewToggle)
        currentSourceName = findViewById(R.id.currentSourceName)
        currentSourceUri = findViewById(R.id.currentSourceUri)
        statusText = findViewById(R.id.statusText)
        libraryList = findViewById(R.id.libraryList)
        speedSlider = findViewById(R.id.speedSlider)
        speedValue = findViewById(R.id.speedValue)
        audioSwitch = findViewById(R.id.audioSwitch)
        fitCover = findViewById(R.id.fitCover)
        fitContain = findViewById(R.id.fitContain)
    }

    private fun configureNavigation() {
        val nav = findViewById<NavigationBarView>(R.id.bottomNavigation)
        nav.selectedItemId = R.id.nav_home
        nav.setOnItemSelectedListener { item ->
            val home = findViewById<View>(R.id.homeScreen)
            val library = findViewById<View>(R.id.libraryScreen)
            val settings = findViewById<View>(R.id.settingsScreen)
            home.visibility = View.GONE
            library.visibility = View.GONE
            settings.visibility = View.GONE
            val target = when (item.itemId) {
                R.id.nav_library -> library
                R.id.nav_settings -> settings
                else -> home
            }
            animatePanelIn(target)
            item.itemId == R.id.nav_home || item.itemId == R.id.nav_library || item.itemId == R.id.nav_settings
        }
    }

    private fun configureActions() {
        findViewById<View>(R.id.btnChoose).setOnClickListener { openVideoPicker() }
        findViewById<View>(R.id.btnUrl).setOnClickListener { showUrlDialog() }
        previewToggle.setOnClickListener { togglePreviewPlayback() }
        findViewById<View>(R.id.btnApply).setOnClickListener { openSystemWallpaperPreview() }
        findViewById<View>(R.id.advancedLink).setOnClickListener {
            findViewById<NavigationBarView>(R.id.bottomNavigation).selectedItemId = R.id.nav_settings
        }
        findViewById<View>(R.id.btnOpenSystemPreview).setOnClickListener { openSystemWallpaperPreview() }
        findViewById<View>(R.id.btnReset).setOnClickListener { resetToDemo() }
        findViewById<View>(R.id.btnClearRecent).setOnClickListener {
            AppPrefs.clearRecent(this)
            renderLibrary()
            toast("Recent sources cleared")
        }

        speedSlider.addOnChangeListener { _, value, fromUser ->
            val rounded = (value * 10).roundToInt() / 10f
            speedValue.text = "${String.format(java.util.Locale.US, "%.1f", rounded)}×"
            if (fromUser) {
                AppPrefs.setSpeed(this, rounded)
                previewPlayer?.setPlaybackSpeed(rounded)
            }
        }

        audioSwitch.setOnCheckedChangeListener { _, isChecked ->
            AppPrefs.setMuted(this, !isChecked)
            previewPlayer?.volume = if (isChecked) 1f else 0f
        }

        fitCover.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                AppPrefs.setFitMode(this, FitMode.COVER)
                playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                previewPlayer?.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            }
        }
        fitContain.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                AppPrefs.setFitMode(this, FitMode.CONTAIN)
                playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                previewPlayer?.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            }
        }
    }

    private fun applyPersistedSettings() {
        val speed = AppPrefs.speed(this)
        speedSlider.value = speed
        speedValue.text = "${String.format(java.util.Locale.US, "%.1f", speed)}×"
        audioSwitch.isChecked = !AppPrefs.muted(this)
        when (AppPrefs.fitMode(this)) {
            FitMode.COVER -> fitCover.isChecked = true
            FitMode.CONTAIN -> fitContain.isChecked = true
        }
    }

    private fun showUrlDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/wallpaper.mp4"
            setSingleLine(true)
            setText(AppPrefs.sourceUri(this@MainActivity)?.takeIf { it.startsWith("https", ignoreCase = true) } ?: "")
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(
                input,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Add video URL")
            .setMessage("Use HTTPS. Direct MP4/WebM files and HLS/DASH manifest URLs are supported when the server allows playback.")
            .setView(container)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Use URL", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val raw = input.text.toString().trim()
                val uri = runCatching { Uri.parse(raw) }.getOrNull()
                val valid = !raw.isBlank() &&
                    uri != null &&
                    uri.scheme.equals("https", ignoreCase = true) &&
                    !uri.host.isNullOrBlank()

                if (!valid) {
                    input.error = "Enter a valid HTTPS video URL"
                    return@setOnClickListener
                }

                AppPrefs.setSource(this, uri, uri.host ?: "Online video")
                AppPrefs.addRecent(this, uri)
                previewUserWantsPlayback = true
                refreshSourceCard()
                renderLibrary()
                configurePreviewPlayer(forceReload = true)
                dialog.dismiss()
                toast("Online video selected")
            }
        }

        dialog.show()
    }

    private fun openVideoPicker() {
        pickVideo.launch(arrayOf("video/*"))
    }

    private fun handlePickedVideo(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Some providers return a one-shot grant only. We still use it for the current selection.
        }
        val name = queryDisplayName(uri) ?: uri.lastPathSegment ?: "Video wallpaper"
        AppPrefs.setSource(this, uri, name)
        AppPrefs.addRecent(this, uri)
        previewUserWantsPlayback = true
        refreshSourceCard()
        renderLibrary()
        configurePreviewPlayer(forceReload = true)
        toast("Wallpaper source selected")
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri.scheme != "content") return uri.lastPathSegment
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
    }

    private fun configurePreviewPlayer(forceReload: Boolean = false) {
        val uriString = AppPrefs.sourceUri(this)
        if (uriString.isNullOrBlank()) {
            playerView.player = null
            previewPlayer?.release()
            previewPlayer = null
            playerView.visibility = View.GONE
            animatedPreview.visibility = View.VISIBLE
            previewLabel.text = "Built-in motion demo"
            previewMeta.text = "Choose a video to preview it here"
            previewToggle.visibility = View.GONE
            return
        }

        animatedPreview.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        previewToggle.visibility = View.VISIBLE

        if (previewPlayer == null) {
            previewPlayer = ExoPlayer.Builder(this).build().also { player ->
                playerView.player = player
                player.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        updatePreviewToggle(isPlaying)
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        previewUserWantsPlayback = false
                        previewLabel.text = "Playback error"
                        previewMeta.text = error.errorCodeName
                        updatePreviewToggle(false)
                        Snackbar.make(findViewById(R.id.root), "This video could not be played", Snackbar.LENGTH_LONG).show()
                    }
                })
            }
        }
        val player = previewPlayer ?: return
        player.volume = if (AppPrefs.muted(this)) 0f else 1f
        player.setPlaybackSpeed(AppPrefs.speed(this))
        player.videoScalingMode = if (AppPrefs.fitMode(this) == FitMode.COVER) {
            C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
        } else {
            C.VIDEO_SCALING_MODE_SCALE_TO_FIT
        }
        if (forceReload || player.mediaItemCount == 0 || player.currentMediaItem?.localConfiguration?.uri.toString() != uriString) {
            player.setMediaItem(buildMediaItem(uriString))
            player.repeatMode = ExoPlayer.REPEAT_MODE_ALL
            player.prepare()
        }
        player.playWhenReady = previewUserWantsPlayback
        previewLabel.text = AppPrefs.sourceName(this)
        previewMeta.text = if (uriString.startsWith("http")) "Online video source" else "Local video source"
    }


    private fun togglePreviewPlayback() {
        val player = previewPlayer ?: return
        if (player.isPlaying) {
            previewUserWantsPlayback = false
            player.pause()
        } else {
            previewUserWantsPlayback = true
            player.play()
        }
        updatePreviewToggle(player.isPlaying)
    }

    private fun updatePreviewToggle(isPlaying: Boolean) {
        previewToggle.setIconResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        previewToggle.contentDescription = if (isPlaying) "Pause preview" else "Play preview"
    }


    private fun buildMediaItem(uriString: String): MediaItem {
        val normalized = uriString.lowercase(java.util.Locale.US)
        val builder = MediaItem.Builder().setUri(uriString)
        when {
            ".m3u8" in normalized -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            ".mpd" in normalized -> builder.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        return builder.build()
    }

    private fun refreshSourceCard() {
        val uri = AppPrefs.sourceUri(this)
        currentSourceName.text = AppPrefs.sourceName(this)
        currentSourceUri.text = uri ?: "Built-in animated preview"
    }

    private fun refreshStatus() {
        val active = runCatching {
            WallpaperManager.getInstance(this).wallpaperInfo?.component?.packageName == packageName
        }.getOrDefault(false)
        statusText.text = if (active) "Live wallpaper is active" else "Wallpaper not active"
    }

    private fun openSystemWallpaperPreview() {
        val component = ComponentName(this, VideoWallpaperService::class.java)
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (_: Exception) {
                toast("This device does not expose the live wallpaper picker")
            }
        }
    }

    private fun resetToDemo() {
        previewUserWantsPlayback = true
        AppPrefs.reset(this)
        applyPersistedSettings()
        refreshSourceCard()
        renderLibrary()
        configurePreviewPlayer(forceReload = true)
        toast("Demo wallpaper restored")
    }

    private fun renderLibrary() {
        libraryList.removeAllViews()
        val recent = AppPrefs.recentUris(this)
        if (recent.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No recent sources yet. Pick a video and it will appear here."
                setTextColor(getColor(R.color.text_secondary))
                textSize = 13f
                setPadding(18, 18, 18, 18)
            }
            libraryList.addView(empty)
            return
        }

        recent.forEach { value ->
            val uri = Uri.parse(value)
            val item = layoutInflater.inflate(R.layout.library_item, libraryList, false)
            val title = item.findViewById<TextView>(R.id.itemTitle)
            val subtitle = item.findViewById<TextView>(R.id.itemSubtitle)
            val use = item.findViewById<View>(R.id.itemUse)
            title.text = queryDisplayName(uri) ?: uri.lastPathSegment ?: "Video wallpaper"
            subtitle.text = value
            use.setOnClickListener {
                AppPrefs.setSource(this, uri, title.text.toString())
                previewUserWantsPlayback = true
                refreshSourceCard()
                configurePreviewPlayer(forceReload = true)
                findViewById<NavigationBarView>(R.id.bottomNavigation).selectedItemId = R.id.nav_home
                toast("Source loaded")
            }
            libraryList.addView(item)
        }
    }


    private fun animatePanelIn(view: View) {
        view.alpha = 0f
        view.translationY = 10f
        view.visibility = View.VISIBLE
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(220L)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()
    }

    private fun runEntranceAnimation() {
        val hero = findViewById<View>(R.id.heroCard)
        hero.alpha = 0f
        hero.translationY = 18f
        hero.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(420)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun toast(message: String) {
        Snackbar.make(findViewById(R.id.root), message, Snackbar.LENGTH_SHORT).show()
    }
}
