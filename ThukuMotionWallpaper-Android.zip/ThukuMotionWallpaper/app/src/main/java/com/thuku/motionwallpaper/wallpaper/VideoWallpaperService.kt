package com.thuku.motionwallpaper.wallpaper

import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.thuku.motionwallpaper.AppPrefs
import com.thuku.motionwallpaper.FitMode
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = WallpaperEngine()

    private inner class WallpaperEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {
        private var player: ExoPlayer? = null
        private var visible = false
        private var surfaceReady = false
        private var lastUri: String? = null
        private var demoFallback = false
        private var xOffset = 0.5f
        private var yOffset = 0.5f

        private val demoHandler = Handler(Looper.getMainLooper())
        private val demoFrame = object : Runnable {
            override fun run() {
                if (!visible || !surfaceReady || player != null) return
                drawDemo(surfaceHolder)
                demoHandler.postDelayed(this, 33L)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            AppPrefs.registerListener(this@VideoWallpaperService, this)
            setOffsetNotificationsEnabled(true)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                demoFallback = false
                attachAndPlay()
                startDemoLoopIfNeeded()
            } else {
                demoHandler.removeCallbacks(demoFrame)
                player?.pause()
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surfaceReady = true
            attachAndPlay()
            startDemoLoopIfNeeded()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceReady = true
            attachAndPlay()
            startDemoLoopIfNeeded()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            surfaceReady = false
            demoHandler.removeCallbacks(demoFrame)
            player?.clearVideoSurfaceHolder(holder)
            super.onSurfaceDestroyed(holder)
        }

        override fun onOffsetsChanged(
            xOffset: Float,
            yOffset: Float,
            xOffsetStep: Float,
            yOffsetStep: Float,
            xPixelOffset: Int,
            yPixelOffset: Int
        ) {
            // Keep video surfaces stable, but use launcher offsets for the built-in animated
            // fallback so home-screen swipes have a subtle, intentional parallax effect.
            this.xOffset = xOffset
            this.yOffset = yOffset
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset)
        }

        override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
            when (key) {
                AppPrefs.KEY_SOURCE_URI -> {
                    demoFallback = false
                    releasePlayer()
                    attachAndPlay()
                    startDemoLoopIfNeeded()
                }

                AppPrefs.KEY_SPEED,
                AppPrefs.KEY_MUTED,
                AppPrefs.KEY_FIT_MODE -> applyPlaybackSettings()
            }
        }

        private fun attachAndPlay() {
            if (!visible || !surfaceReady) return

            val uriString = AppPrefs.sourceUri(this@VideoWallpaperService)
            if (uriString.isNullOrBlank()) {
                releasePlayer()
                demoFallback = false
                startDemoLoopIfNeeded()
                return
            }

            if (demoFallback) {
                startDemoLoopIfNeeded()
                return
            }

            val uri = runCatching { Uri.parse(uriString) }.getOrNull()
            if (uri == null) {
                enterDemoFallback("Invalid wallpaper URI")
                return
            }

            val p = player ?: ExoPlayer.Builder(this@VideoWallpaperService).build().also { created ->
                created.repeatMode = Player.REPEAT_MODE_ALL
                created.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        Log.w(TAG, "Wallpaper video playback failed: ${error.errorCodeName}")
                        enterDemoFallback("Video playback failed")
                    }
                })
                player = created
            }

            val changed = lastUri != uriString
            if (changed || p.mediaItemCount == 0) {
                p.setMediaItem(buildMediaItem(uriString))
                p.prepare()
                lastUri = uriString
            }

            demoHandler.removeCallbacks(demoFrame)
            p.setVideoSurfaceHolder(surfaceHolder)
            applyPlaybackSettings()
            p.playWhenReady = true
        }


        private fun buildMediaItem(uriString: String): MediaItem {
            val normalized = uriString.lowercase(java.util.Locale.US)
            val builder = MediaItem.Builder().setUri(uriString)
            when {
                ".m3u8" in normalized -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
                ".mpd" in normalized -> builder.setMimeType(MimeTypes.APPLICATION_MPD)
            }
            return builder.build()
        }

        @OptIn(UnstableApi::class)
        private fun applyPlaybackSettings() {
            val p = player ?: return
            p.videoScalingMode = if (AppPrefs.fitMode(this@VideoWallpaperService) == FitMode.COVER) {
                C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            } else {
                C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            }
            p.volume = if (AppPrefs.muted(this@VideoWallpaperService)) 0f else 1f
            p.setPlaybackSpeed(AppPrefs.speed(this@VideoWallpaperService))
        }

        private fun startDemoLoopIfNeeded() {
            if (!visible || !surfaceReady || player != null) return
            val hasSource = !AppPrefs.sourceUri(this@VideoWallpaperService).isNullOrBlank()
            if (hasSource && !demoFallback) return
            demoHandler.removeCallbacks(demoFrame)
            demoHandler.post(demoFrame)
        }

        private fun enterDemoFallback(reason: String) {
            Log.w(TAG, reason)
            demoFallback = true
            releasePlayer()
            startDemoLoopIfNeeded()
        }

        private fun drawDemo(holder: SurfaceHolder) {
            val canvas: Canvas = runCatching { holder.lockCanvas() }.getOrNull() ?: return
            try {
                canvas.drawColor(Color.rgb(7, 8, 11))
                val w = canvas.width.toFloat()
                val h = canvas.height.toFloat()
                val minSide = min(w, h)
                val now = System.nanoTime() / 1_000_000_000f
                val parallaxX = (xOffset - 0.5f) * w * 0.12f
                val parallaxY = (yOffset - 0.5f) * h * 0.08f
                val cx = w * (0.5f + 0.16f * cos(now * 0.7f)) + parallaxX
                val cy = h * (0.5f + 0.12f * sin(now * 0.55f)) + parallaxY
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(
                        cx,
                        cy,
                        minSide * 0.62f,
                        0x44E9FF6A,
                        0x00000000,
                        Shader.TileMode.CLAMP
                    )
                }
                canvas.drawCircle(cx, cy, minSide * 0.62f, paint)

                paint.shader = RadialGradient(
                    w * (0.72f + 0.08f * sin(now * 0.43f)) + parallaxX * 0.5f,
                    h * (0.28f + 0.10f * cos(now * 0.51f)) + parallaxY * 0.5f,
                    minSide * 0.35f,
                    0x226AE5FF,
                    0x00000000,
                    Shader.TileMode.CLAMP
                )
                canvas.drawCircle(w * 0.72f, h * 0.28f, minSide * 0.35f, paint)

                paint.shader = null
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = maxOf(2f, minSide * 0.004f)
                paint.color = 0x55E9FF6A.toInt()
                val ringRadius = minSide * (0.16f + 0.018f * sin(now * 1.2f))
                canvas.drawCircle(w / 2f + parallaxX * 0.6f, h / 2f + parallaxY * 0.6f, ringRadius, paint)

                paint.style = Paint.Style.FILL
                paint.color = 0xFFE9FF6A.toInt()
                val radius = minSide * (0.075f + 0.008f * sin(now * 2f))
                canvas.drawCircle(w / 2f + parallaxX * 0.75f, h / 2f + parallaxY * 0.75f, radius, paint)
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun releasePlayer() {
            demoHandler.removeCallbacks(demoFrame)
            player?.clearVideoSurface()
            player?.release()
            player = null
            lastUri = null
        }

        override fun onDestroy() {
            AppPrefs.unregisterListener(this@VideoWallpaperService, this)
            demoHandler.removeCallbacksAndMessages(null)
            releasePlayer()
            super.onDestroy()
        }
    }

    private companion object {
        const val TAG = "MotionWallpaper"
    }
}
