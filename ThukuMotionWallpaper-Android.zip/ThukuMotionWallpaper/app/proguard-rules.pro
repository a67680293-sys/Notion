# Project-specific R8 rules. Media3 and Android framework components are handled by their
# consumer rules; keep this file intentionally small so releases stay maintainable.
