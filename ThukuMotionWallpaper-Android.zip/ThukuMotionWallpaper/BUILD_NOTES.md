# Build / Test Notes

This project is a native Android live-wallpaper app. It does not contain the old generated web portal, overlay service, or generated branding.

## Android Studio

1. Open the `ThukuMotionWallpaper` folder in Android Studio.
2. Let Gradle sync using a JDK 17 runtime.
3. Connect an Android device or create an emulator.
4. Run the `app` configuration.
5. For the live wallpaper, launch the app, choose a local video or HTTPS source, then press **Set wallpaper**.

## Command line

Use a valid local Gradle 9.6.0 installation:

```bash
gradle :app:testDebugUnitTest :app:assembleDebug
```

The archive intentionally does not include a Gradle wrapper JAR because the uploaded source archive contained a corrupt wrapper JAR. The included GitHub Actions workflow installs Gradle 9.6.0 and builds the debug APK.

## What was statically checked in this rebuild

- XML resources parse successfully.
- A dependency-free static verification script checks the resource graph, view IDs, wallpaper manifest, and legacy-removal requirements.
- All `R.id` references resolve to declared layout/menu IDs.
- Legacy generated branding and overlay-specific implementation strings are absent from shipped app sources.
- The rebuilt app has no draw-over-other-apps permission or foreground overlay service.
- The live wallpaper service is declared with `BIND_WALLPAPER` and wallpaper metadata.
- The project structure is a single Android application module.

A full APK/device run could not be executed in the supplied environment because no Android SDK/Gradle installation was available locally.
