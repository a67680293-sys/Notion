#!/usr/bin/env python3
"""Dependency-free structural checks for the Motion Wallpaper project."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app" / "src" / "main" / "res"
errors = []

xml_files = list(RES.rglob("*.xml"))
for path in xml_files:
    try:
        ET.parse(path)
    except Exception as exc:
        errors.append(f"XML parse failed: {path}: {exc}")

resource_types = {"drawable", "layout", "menu", "mipmap", "string", "color", "style", "xml"}
resources = {kind: set() for kind in resource_types}
for path in xml_files:
    rel = path.relative_to(RES)
    folder = rel.parts[0]
    base = folder.split("-")[0]
    if base in resources and base not in {"string", "color", "style"}:
        resources[base].add(path.stem)
    elif base == "values":
        for kind, name in re.findall(
            r'<(drawable|layout|menu|string|color|style)\s+name="([^"]+)"',
            path.read_text(errors="ignore"),
        ):
            if kind in resources:
                resources[kind].add(name)

for path in xml_files:
    text = path.read_text(errors="ignore")
    for kind, name in re.findall(r'@([A-Za-z0-9_]+)/([A-Za-z0-9_.-]+)', text):
        if kind in resources and name not in resources[kind] and not text[max(0, text.find(f"@{kind}/{name}") - 12):].startswith("android:"):
            # Framework values are written as @android:..., so an unqualified missing app resource is real.
            errors.append(f"Missing @{kind}/{name}: {path}")

ids = set()
for path in xml_files:
    ids.update(re.findall(r'@\+id/([A-Za-z0-9_]+)', path.read_text(errors="ignore")))
for path in (ROOT / "app" / "src" / "main" / "java").rglob("*.kt"):
    text = path.read_text(errors="ignore")
    for name in re.findall(r'R\.id\.([A-Za-z0-9_]+)', text):
        if name not in ids:
            errors.append(f"Missing R.id.{name}: {path}")

scan_roots = [
    ROOT / "app" / "src" / "main",
    ROOT / "app" / "build.gradle.kts",
    ROOT / "build.gradle.kts",
    ROOT / "settings.gradle.kts",
    ROOT / ".github" / "workflows",
]
scan_files = []
for root in scan_roots:
    if root.is_file():
        scan_files.append(root)
    elif root.is_dir():
        scan_files.extend(p for p in root.rglob("*") if p.is_file())
text = "\n".join(p.read_text(errors="ignore") for p in scan_files)
for forbidden in (
    "com.example." + "motionoverlay",
    "SYSTEM_" + "ALERT_WINDOW",
    "TYPE_" + "APPLICATION_OVERLAY",
    "startForeground" + "Service",
    "Overlay" + "Service",
    "Sensor" + "Manager",
    "Gem" + "ini",
    "AI" + " " + "Studio",
):
    if forbidden.lower() in text.lower():
        errors.append(f"Forbidden legacy/branding string found in shipped sources: {forbidden}")

required_files = [
    ROOT / "app" / "src" / "main" / "AndroidManifest.xml",
    ROOT / "app" / "src" / "main" / "java" / "com" / "thuku" / "motionwallpaper" / "MainActivity.kt",
    ROOT / "app" / "src" / "main" / "java" / "com" / "thuku" / "motionwallpaper" / "AppPrefs.kt",
    ROOT / "app" / "src" / "main" / "java" / "com" / "thuku" / "motionwallpaper" / "wallpaper" / "VideoWallpaperService.kt",
    ROOT / "app" / "src" / "main" / "java" / "com" / "thuku" / "motionwallpaper" / "ui" / "AnimatedPreviewView.kt",
    ROOT / "app" / "src" / "main" / "res" / "layout" / "activity_main.xml",
    ROOT / ".github" / "workflows" / "android-build.yml",
]
for required_file in required_files:
    if not required_file.exists():
        errors.append(f"Required project file missing: {required_file.relative_to(ROOT)}")

main_activity = (ROOT / "app" / "src" / "main" / "java" / "com" / "thuku" / "motionwallpaper" / "MainActivity.kt").read_text(errors="ignore")
if "import kotlin.math.roundToInt" not in main_activity:
    errors.append("MainActivity.kt is missing the roundToInt import used by the speed slider")

app_gradle = (ROOT / "app" / "build.gradle.kts").read_text(errors="ignore")
for dependency in ("media3-exoplayer-hls", "media3-exoplayer-dash"):
    if dependency not in app_gradle:
        errors.append(f"Media streaming dependency missing: {dependency}")

manifest = (ROOT / "app" / "src" / "main" / "AndroidManifest.xml").read_text()
for required in (
    'android:permission="android.permission.BIND_WALLPAPER"',
    'android.service.wallpaper.WallpaperService',
    'android:name="android.service.wallpaper"',
):
    if required not in manifest:
        errors.append(f"Wallpaper manifest requirement missing: {required}")

if errors:
    print("STATIC VERIFY: FAIL")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"STATIC VERIFY: PASS ({len(xml_files)} XML resources, {len(ids)} declared view/menu IDs)")
